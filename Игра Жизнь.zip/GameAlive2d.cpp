#include<stdio.h>
#include<stdlib.h>
#include"TXLib.h"
#include<windows.h>
#define Max 70
#define TIM 100
#define MM 700
int f(int i, int MM){
int f;
f=(i+MM)%MM;
return f;
}
int nbr(int i, int j, int MM, int *a){
    int x=f(i-1, MM);
    int y=f(i+1, MM);
    int z=f(j-1, MM);
    int g=f(j+1, MM);
    int h=a[x, z] + a[x, j] + a[x, g]+
          a[i, z] +         + a[i, g]+
          a[y, z] + a[y, j] + a[y, g];

    return h;
}

void nbm(int i, int j, int MM, int *a){
    if(nbr(i, j, MM, a)==2 & nbr(i, j, MM, a)==3){
        a[i+2, j]=1;
    }else{a[i+2, j]=0;}
}
void print(int i, int j, int MM, int *a){
    int x;
    for(x=0;x<MM;x++){
       if(a[i+2, j]==1){
        printf("%d", txSetPixel(i+2, j, TX_WHITE))
       }
    }
    printf("\n");
    Sleep(TIM);
}

void copyr(int n, int *d, int*h, int *f,  int *s){

    for(int x=0; x<n; x++){
        d[x]=h[x];
    }

    for(int x=0; x<n; x++){
        h[x]=f[x];
    }
       for(int x=0; x<n; x++){
        f[x]=s[x];
    }
}
void gen(int *a, int n){
    for(int i=0; i<n; i++){
        a[i]=(i%7)%2;
    }
}
void neg(int *a, int n){
    for(int i=0; i<n; i++){
        a[i]=0;
    }
}

void step(int n,int *a, int *d, int *f, int *h){
    int x;
    for(x=0; x<n; x++){
        nbm(x, n, a, d, f, h);
    }
}

int main()
{
    txCreateWindow (MM, MM);
    int d[Max]; // �����������int *f,���� ������
    int a[Max]; // �������� ������
    int k[Max]; // ������ ������
    int m[Max]; // ������ ������
    gen(a, Max);
    gen(k, Max);
    gen(m, Max);
    print(Max, a);
    print(Max, k);
    print(Max, m);
    while(1){
            step(Max, a, d, k, m);
            print(Max, d);
            copyr(Max, d, m, k, a);
    }
    return 0;
}
